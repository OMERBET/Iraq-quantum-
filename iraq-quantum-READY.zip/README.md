# 🚀 Iraq Quantum Lab

**مختبر الحوسبة الكمية العراقي - الأول في العراق**

## 🌐 رابط الموقع:
```
https://iraq-quantum-lab.pages.dev
```

## 📦 الملفات:
- `public/index.html` - الواجهة الرئيسية
- `functions/api/[[path]].js` - API محمي بـ WAF
- `package.json` - Dependencies
- `wrangler.toml` - إعدادات Cloudflare

## 🔐 Environment Variables (أضفها في Cloudflare):
```
SUPABASE_URL=https://ogerlqawiaondcqwxhju.supabase.co
SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9nZXJscWF3aWFvbmRjcXd4aGp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5NjQ4MzcsImV4cCI6MjA4ODU0MDgzN30.yKCChJ_2YBJHAQySt1wqWxvNeZ_nqFZHxAi-WYoveLk
ANTHROPIC_API_KEY=احصل عليه من console.anthropic.com
ADMIN_EMAIL=jaafarabdulsalam49@gmail.com
```

## 🚀 النشر:
```bash
git add .
git commit -m "🚀 Deploy"
git push
```

---

Made with ❤️ in Iraq 🇮🇶
