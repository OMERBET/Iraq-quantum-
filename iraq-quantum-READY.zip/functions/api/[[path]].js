// ════════════════════════════════════════════════════════════════════════════
// 🔒 IRAQ QUANTUM LAB - Cloudflare Pages Function
// ════════════════════════════════════════════════════════════════════════════
// File: functions/api/[[path]].js
// This handles ALL /api/* requests
// ════════════════════════════════════════════════════════════════════════════

import { createClient } from '@supabase/supabase-js';

// ══════════════════════════════════════════════════════════════════════════
// 🛡️ WAF PROTECTION
// ══════════════════════════════════════════════════════════════════════════

class WAF {
  static detectSQLInjection(input) {
    if (typeof input !== 'string') return false;
    const patterns = [
      /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC)\b)/gi,
      /(UNION\s+SELECT)/gi,
      /(\bOR\b\s+['"]?\d+['"]?\s*=\s*['"]?\d+)/gi,
      /(--|\#|\/\*)/g
    ];
    return patterns.some(p => p.test(input));
  }
  
  static detectXSS(input) {
    if (typeof input !== 'string') return false;
    const patterns = [
      /<script[^>]*>.*?<\/script>/gi,
      /<iframe[^>]*>/gi,
      /javascript:/gi,
      /on\w+\s*=/gi
    ];
    return patterns.some(p => p.test(input));
  }
  
  static detectPathTraversal(input) {
    if (typeof input !== 'string') return false;
    const patterns = [/\.\.\//g, /\.\.\\/g, /%2e%2e/gi, /etc\/passwd/gi];
    return patterns.some(p => p.test(input));
  }
  
  static detectCommandInjection(input) {
    if (typeof input !== 'string') return false;
    const patterns = [/[;&|`$()]/g, /(bash|sh|cmd|rm|chmod)\s/gi];
    return patterns.some(p => p.test(input));
  }
  
  static sanitize(input, maxLength = 1000) {
    if (input === null || input === undefined) return '';
    
    if (typeof input === 'object') {
      const dangerous = ['__proto__', 'constructor', '$ne', '$gt', '$where'];
      if (dangerous.some(k => k in input)) {
        throw new Error('⚠️ Malicious object detected');
      }
      return input;
    }
    
    let sanitized = String(input);
    
    if (this.detectSQLInjection(sanitized)) throw new Error('⚠️ SQL Injection detected');
    if (this.detectXSS(sanitized)) throw new Error('⚠️ XSS Attack detected');
    if (this.detectPathTraversal(sanitized)) throw new Error('⚠️ Path Traversal detected');
    if (this.detectCommandInjection(sanitized)) throw new Error('⚠️ Command Injection detected');
    
    return sanitized
      .replace(/[<>]/g, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+=/gi, '')
      .trim()
      .slice(0, maxLength);
  }
  
  static deepSanitize(obj) {
    if (!obj || typeof obj !== 'object') return this.sanitize(obj);
    if (Array.isArray(obj)) return obj.map(i => this.deepSanitize(i));
    
    const clean = {};
    for (const [key, value] of Object.entries(obj)) {
      clean[this.sanitize(key, 100)] = this.deepSanitize(value);
    }
    return clean;
  }
}

// ══════════════════════════════════════════════════════════════════════════
// 🛡️ RATE LIMITING (KV-based)
// ══════════════════════════════════════════════════════════════════════════

async function checkRateLimit(env, ip) {
  if (!env.KV) return true; // Skip if KV not configured
  
  const key = `rate:${ip}`;
  const current = await env.KV.get(key);
  
  if (!current) {
    await env.KV.put(key, '1', { expirationTtl: 60 });
    return true;
  }
  
  const count = parseInt(current);
  if (count >= 10) return false;
  
  await env.KV.put(key, String(count + 1), { expirationTtl: 60 });
  return true;
}

async function recordAttack(env, ip) {
  if (!env.KV) return;
  
  const key = `attacks:${ip}`;
  const current = await env.KV.get(key);
  const attacks = current ? parseInt(current) + 1 : 1;
  
  await env.KV.put(key, String(attacks), { expirationTtl: 86400 }); // 24h
  return attacks >= 3; // Block after 3 attacks
}

async function isBlocked(env, ip) {
  if (!env.KV) return false;
  
  const key = `attacks:${ip}`;
  const current = await env.KV.get(key);
  return current && parseInt(current) >= 3;
}

// ══════════════════════════════════════════════════════════════════════════
// 🌐 CORS
// ══════════════════════════════════════════════════════════════════════════

const ALLOWED_ORIGINS = [
  'https://iraq-quantum-lab.pages.dev',
  'https://your-domain.com',
  'http://localhost:3000'
];

function getCorsHeaders(origin) {
  const allowed = ALLOWED_ORIGINS.includes(origin);
  return {
    'Access-Control-Allow-Origin': allowed ? origin : ALLOWED_ORIGINS[0],
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block'
  };
}

// ══════════════════════════════════════════════════════════════════════════
// 🎯 MAIN HANDLER
// ══════════════════════════════════════════════════════════════════════════

export async function onRequest(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const origin = request.headers.get('origin') || '';
  const corsHeaders = getCorsHeaders(origin);
  
  // OPTIONS
  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  
  // Only POST
  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: corsHeaders
    });
  }
  
  // Get IP
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  
  // Check if blocked
  if (await isBlocked(env, ip)) {
    return new Response(JSON.stringify({ 
      error: '🚫 Your IP has been blocked' 
    }), {
      status: 403,
      headers: corsHeaders
    });
  }
  
  // Rate limiting
  const allowed = await checkRateLimit(env, ip);
  if (!allowed) {
    return new Response(JSON.stringify({ 
      error: 'Too many requests. Try again in 1 minute.' 
    }), {
      status: 429,
      headers: corsHeaders
    });
  }
  
  try {
    const body = await request.json();
    let { action, data } = body;
    
    // WAF Protection
    try {
      data = WAF.deepSanitize(data);
    } catch (wafError) {
      const blocked = await recordAttack(env, ip);
      console.error(`⚠️ WAF Alert [${ip}]:`, wafError.message);
      
      return new Response(JSON.stringify({ 
        error: wafError.message,
        blocked: blocked ? 'IP flagged' : undefined
      }), {
        status: 400,
        headers: corsHeaders
      });
    }
    
    // Initialize Supabase
    const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_KEY);
    
    // Routes
    switch (action) {
      
      case 'signup': {
        const { email, name } = data;
        
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          return new Response(JSON.stringify({ 
            error: '⚠️ البريد الإلكتروني غير صحيح' 
          }), { status: 400, headers: corsHeaders });
        }
        
        const { error } = await supabase.auth.signInWithOtp({
          email,
          options: { data: { full_name: name }, shouldCreateUser: true }
        });
        
        if (error) throw error;
        
        return new Response(JSON.stringify({ 
          success: true, 
          message: '✅ تم إرسال رمز التحقق' 
        }), { headers: corsHeaders });
      }
      
      case 'verify': {
        const { email, token } = data;
        
        if (!/^\d{6}$/.test(token)) {
          return new Response(JSON.stringify({ 
            error: '⚠️ الرمز يجب أن يكون 6 أرقام' 
          }), { status: 400, headers: corsHeaders });
        }
        
        const { data: session, error } = await supabase.auth.verifyOtp({
          email, token, type: 'email'
        });
        
        if (error) {
          return new Response(JSON.stringify({ 
            error: '❌ رمز خاطئ' 
          }), { status: 400, headers: corsHeaders });
        }
        
        return new Response(JSON.stringify({ 
          success: true, 
          session: session.session 
        }), { headers: corsHeaders });
      }
      
      case 'login': {
        const { email, password } = data;
        
        if (!email || !password) {
          return new Response(JSON.stringify({ 
            error: '⚠️ أدخل البريد وكلمة المرور' 
          }), { status: 400, headers: corsHeaders });
        }
        
        const { data: session, error } = await supabase.auth.signInWithPassword({
          email, password
        });
        
        if (error) {
          return new Response(JSON.stringify({ 
            error: '❌ خطأ في الدخول' 
          }), { status: 401, headers: corsHeaders });
        }
        
        return new Response(JSON.stringify({ 
          success: true, 
          session 
        }), { headers: corsHeaders });
      }
      
      case 'chat': {
        const { question } = data;
        
        if (!question || question.length < 3) {
          return new Response(JSON.stringify({ 
            error: '⚠️ السؤال قصير' 
          }), { status: 400, headers: corsHeaders });
        }
        
        const response = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': env.ANTHROPIC_API_KEY,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify({
            model: 'claude-3-5-sonnet-20241022',
            max_tokens: 2000,
            messages: [{
              role: 'user',
              content: `أنت خبير حوسبة كمية. أجب بالعربي:\n\n${question}`
            }]
          })
        });
        
        if (!response.ok) throw new Error('AI API failed');
        
        const result = await response.json();
        const answer = result.content?.[0]?.text || 'لا يوجد رد';
        
        return new Response(JSON.stringify({ 
          success: true, 
          answer 
        }), { headers: corsHeaders });
      }
      
      case 'admin_users': {
        const { token } = data;
        
        if (!token) {
          return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401, headers: corsHeaders
          });
        }
        
        const { data: { user }, error: userError } = await supabase.auth.getUser(token);
        
        if (userError || !user || user.email !== env.ADMIN_EMAIL) {
          return new Response(JSON.stringify({ error: 'Access denied' }), {
            status: 403, headers: corsHeaders
          });
        }
        
        const adminClient = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_KEY || env.SUPABASE_KEY);
        const { data: users, error } = await adminClient.auth.admin.listUsers();
        
        if (error) throw error;
        
        return new Response(JSON.stringify({ 
          success: true, 
          users: users.users || [] 
        }), { headers: corsHeaders });
      }
      
      default:
        return new Response(JSON.stringify({ 
          error: 'Invalid action' 
        }), {
          status: 400,
          headers: corsHeaders
        });
    }
    
  } catch (error) {
    console.error('API Error:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Internal error' 
    }), {
      status: 500,
      headers: corsHeaders
    });
  }
}
